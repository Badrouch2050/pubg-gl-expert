PUBG GL Expert v4.1 - Developed by TNL YORYO
Discord : https://discord.gg/qVRBMt74h

[FR] 1) Extraire le zip  2) Double-cliquer "PUBG GL Expert.exe"  3) Accepter la demande administrateur
     4) Suivre l'assistant en 8 etapes. Si SmartScreen s'affiche : "Informations complementaires" > "Executer quand meme".
     Ne redemarrez pas le PC avant l'etape 5 "Verrouillage final".

[EN] 1) Extract the zip  2) Double-click "PUBG GL Expert.exe"  3) Accept the administrator prompt
     4) Follow the 8-step wizard. If SmartScreen appears: "More info" > "Run anyway".
     Don't restart your PC before step 5 "Final lock".

[AR] 1) استخرج ملف zip  2) انقر مرتين على "PUBG GL Expert.exe"  3) وافق على طلب صلاحيات المسؤول
     4) اتبع المساعد المكون من 8 خطوات. إذا ظهر SmartScreen: "مزيد من المعلومات" ثم "تشغيل على أي حال".
     لا تعد تشغيل الكمبيوتر قبل الخطوة 5 "القفل النهائي".
